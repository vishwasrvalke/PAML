import splunklib.client as client
import splunklib.results as results
import csv
dictsample={}
HOST = "losatlshs01.ecs.lowes.com"
PORT = 8089
USERNAME = "sraocr"
PASSWORD = "Lowes#123"
service = client.connect(
    host=HOST,
    port=PORT, 
    username=USERNAME,
    password=PASSWORD)

listofquery=['search index = nmon host=losatlaps22 type=CPU_ALL earliest=-60m@d | stats avg(cpu_user_percent)','search index = nmon host=losatlaps22 eventtype="nmon:performance:storage"  earliest=-60m@d | stats avg(storage_free_percent)']
for querys in listofquery:
    rr = results.ResultsReader(service.jobs.export(querys))
    for result in rr:
        if isinstance(result, results.Message):
        # Diagnostic messages might be returned in the results
            print(result.type, result.message)
        elif isinstance(result, dict):
        # Normal events are returned as dicts
            '''for key,value in result.items():
                print(value)'''
            dictsample.update(result.items())
    assert rr.is_preview == False
#print(dictsample)

#write the result into to a csv file
keys, values = [], []

for key, value in dictsample.items():
    keys.append(key)
    values.append(value)       
try:
    #path of the outfile is C:\Users\sraocr\workspace\splunkrestAPI\request
    with open('resultsofquerysame.csv', 'w') as outfile:
        csvwriter = csv.writer(outfile)
        csvwriter.writerow(keys)
        csvwriter.writerow(values)
except IOError as e:
    print(e)