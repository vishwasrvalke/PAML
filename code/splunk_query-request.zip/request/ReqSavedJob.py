from time import sleep
import sys
import splunklib.client as client
import splunklib.results as results

HOST = "losatlshs01.ecs.lowes.com"
PORT = 8089
USERNAME = "sraocr"
PASSWORD = "Lowes#123"
service = client.connect(
    host=HOST,
    port=PORT, 
    username=USERNAME,
    password=PASSWORD)
...

# Retrieve the new search
mysavedsearch = service.saved_searches["nmon-losataps22-avg"]

# Run the saved search
job = mysavedsearch.dispatch()

# Create a small delay to allow time for the update between server and client
sleep(2)

# Wait for the job to finish--poll for completion and display stats
while True:
    job.refresh()
    stats = {"isDone": job["isDone"],
             "doneProgress": float(job["doneProgress"])*100,
              "scanCount": int(job["scanCount"]),
              "eventCount": int(job["eventCount"]),
              "resultCount": int(job["resultCount"])}
    status = ("\r%(doneProgress)03.1f%%   %(scanCount)d scanned   "
              "%(eventCount)d matched   %(resultCount)d results") % stats
              
    sys.stdout.write(status)
    sys.stdout.flush()
    if stats["isDone"] == "1":
        break 
    sleep(2)

# Display the search results now that the job is done
jobresults = job.results()

while True:
    content = jobresults.read(1024)
    if len(content) == 0:
        
        break
    sys.stdout.write(str(content))
    sys.stdout.flush()
    sys.stdout.write("\n")