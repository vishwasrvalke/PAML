import splunklib.client as client
import splunklib.results as results

HOST = "losatlshs01.ecs.lowes.com"
PORT = 8089
USERNAME = "sraocr"
PASSWORD = "Lowes#123"
OWNER = "sraocr"       
APP   = "search"

service = client.connect(
    host=HOST,
    port=PORT, 
    username=USERNAME,
    password=PASSWORD)

service2 = client.connect(
    host=HOST,
    port=PORT,
    username=USERNAME,
    password=PASSWORD,
    owner=OWNER,
    app=APP)
savedsearches2 = service2.saved_searches

for savedsearch in savedsearches2:
    print( "  " + savedsearch.name)