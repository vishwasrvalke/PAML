import splunklib.client as client
import splunklib.results as results
import csv
import re
dictsample={}
host_name=[]
HOST = "losatlshs01.ecs.lowes.com"
PORT = 8089
USERNAME = "sraocr"
PASSWORD = "Lowes#123"
service = client.connect(
    host=HOST,
    port=PORT, 
    username=USERNAME,
    password=PASSWORD)
listofquerys=[]
num_lines=0
listoffolders=['cpu','mem']
for foldername in listoffolders:
    file1 = open('C:\\Users\\sraocr\\workspace\\splunkrestAPI\\request\\'+foldername+"query.txt","r+")
    t_num_lines =sum(1 for line in open('C:\\Users\\sraocr\\workspace\\splunkrestAPI\\request\\'+foldername+"query.txt"))
    num_lines=num_lines+t_num_lines
    host_name=[]
    num_lines=0
    for i in range(t_num_lines):
        line=file1.readline()
        host_name.append(re.findall(r"losatlaps\d+",line))
        listofquerys.append(line)
print(listofquerys)
print(host_name)
for querys in listofquerys:
    print(querys) 
    rr = results.ResultsReader(service.jobs.export(querys))
    lists=[]
    for result in rr:
        if isinstance(result, results.Message):
        # Diagnostic messages might be returned in the results
            print(result.type, result.message)
        elif isinstance(result, dict):
        # Normal events are returned as dicts
            lists.append(dict(result))
    print(len(lists))
    assert rr.is_preview == False
    try:
    #path of the outfile is C:\Users\sraocr\workspace\splunkrestAPI\request
        for i in range(num_lines):
            print(num_lines)
            filename= 'C:\\Users\\sraocr\\workspace\\splunkrestAPI\\request\\'+str(host_name[i])+'\\'
            
            sample=filename+str(host_name[i])+listoffolders[i]+'.csv'
            print(sample)
            print(len(lists))
            with open(sample, 'a', newline='') as outfile:
                
                for i in range(len(lists)):
                    csvwriter = csv.writer(outfile)
                    if i == 0:
                        csvwriter.writerow(list(lists[i].keys()))
                    csvwriter.writerow(list(lists[i].values()))
    except IOError as e:
        print(e)



#write the result into to a csv file

        

    

