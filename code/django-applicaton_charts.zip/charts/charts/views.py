

from django.shortcuts import render
from django.views.generic import View

from rest_framework.views import APIView
from rest_framework.response import Response

import csv

path=['C:\\Users\\sraocr\\Downloads\\cleandata\\wheap1.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wheap2.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wheap3.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wjdbc1.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wjdbc2.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wjdbc3.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wmem_used22.csv','C:\\Users\\sraocr\\Downloads\\cleandata\\wcpu_used22.csv',]
def fetch_dict(path):
    dict_l={}
    reader = csv.DictReader(open(path))
    for line in reader:
        dict_l.update({line['date']:line['value']})
    return dict_l

heap_dict=fetch_dict(path[0])
heap_dict1=fetch_dict(path[1])
heap_dict2=fetch_dict(path[2])
jdbc_dict3=fetch_dict(path[3])
jdbc_dict4=fetch_dict(path[4])
jdbc_dict5=fetch_dict(path[5])
cpu_dict6=fetch_dict(path[6])
mem_dict7=fetch_dict(path[7])
       
dict_names=['heap_dict','heap_dict1','heap_dict2','jdbc_dict3','jdbc_dict4','jdbc_dict5','cpu_dict6','mem_dict7']
list_value=[]
data_tosend={}
def conver(temp_dict): 
    conver_sample_value=[[],[]]
    for key,value in temp_dict.items():
        conver_sample_value[0].append(key)
        conver_sample_value[1].append(float(value))
    return conver_sample_value   
#print(sample_dict.keys)
#print(sample_value) 
def ret_list(temp_strdict):
    temp_dict=eval(temp_strdict)
    ret_list_value=[]
    ret_list_value=conver(temp_dict)
    return ret_list_value



for name in dict_names:
    list_value=ret_list(name)
    dict_kname=str(name)+'_key'
    dict_vname=str(name)+'_value'
    data_tosend.update({dict_kname:list_value[0],dict_vname:list_value[1]})   
        

class HomeView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'charts.html', {})

class ChartData(APIView):

    authentication_classes =[]
    permission_classes =[]

    def get(self, request, format=None):
        data = data_tosend
        return Response(data)