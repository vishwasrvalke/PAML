
from django.http import JsonResponse
from django.shortcuts import render
from django.views.generic import View

from rest_framework.views import APIView
from rest_framework.response import Response

class HomeView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'charts.html', {})

def get_data(request, *args, **kwargs):
    data={
            "sales": 100,
            "customers": 10,
    }
    return JsonResponse(data)

class ChartData(APIView):

    authentication_classes =[]
    permission_classes =[]

    def get(self, request, format=None):
        
        default_items = {'3/31/2019  8:00:00 AM':1.558823529,'3/31/2019  9:00:00 AM': 1.3125, '3/31/2019  10:00:00 AM':1.5, '3/31/2019  11:00:00 AM':1.4, '3/31/2019  12:00:00 PM':1.48333333333333, '3/31/2019  1:00:00 PM':1.17777777777777}
        data = {
                
                "default": default_items,
                
        }
        return Response(data)
    