{% extends 'base.html' %}

<script>
{% block jquery %}
var endpoint = '/api/chart/data/'
var xdata = []
var ydata = []
var xdata1 = []
var ydata1 = []
var dataPoint = []
var chartid= []
$.ajax({
			method: "GET",
			url: endpoint,
			success: function(data){
					xdata = data.sample_key
					console.log(xdata)
					ydata = data.sample_value
					console.log(ydata)
					xdata1 = data.sample_key1
					
					ydata1 = data.sample_value1
					
                plot(xdata,ydata,"chartContainer")
                console.log(xdata1)
                console.log(ydata1)
                plot(xdata1,ydata1,"chartContainer1")   
                 
                        },

            error: function(error_data){
                console.log("error")
                console.log(error_data)
            }
})
function plot(datax,datay,container_id){
                    addData(datax,datay)
                    setChart(container_id)				
                }
                        
function addData(s,d) {
                	for (var i = 0; i < s.length; i++) {
                		dataPoint.push({
                			x: new Date(s[i]),
                			y: d[i]
                		});
                 }
                 
                }
function setChart(chartid){
                var chart = new CanvasJS.Chart(chartid,
                {
                    animationEnabled: true,
                    theme: "light2",
                    title: {
                        text: "Date Time Formatting"               
                    },
                    axisX:{      
                        valueFormatString: "D-MM hh:mm tt" ,
                        labelAngle: -50
                    },
                    axisY: {
                      valueFormatString: "#,###"
                  },
                
                  data: [
                  {        
                    type: "spline",
                    color: "rgba(0,75,141,0.7)",
                    dataPoints: dataPoint
                }
                
                ]
                });
                chart.render();
            }                


    
{% endblock %}
</script>

{% block content %}
<div class='row'>
<div class='col-sm-12' >
    <div class='col-sm-6'>
        <div id="chartContainer" style="height: 300px; width: 100%;"></div>
    </div>
    <div class='col-sm-6'>    
        <div id="chartContainer1" style="height: 300px; width: 100%;"></div>
    </div>
</div>

{% endblock content %}
