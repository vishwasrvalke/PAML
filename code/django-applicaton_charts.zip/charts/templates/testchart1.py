{% extends 'base.html' %}

<script>
{% block jquery %}
var endpoint = '/api/chart/data/'
var xdata = []
var ydata = []
$.ajax({
			method: "GET",
			url: endpoint,
			success: function(data){
					xdata = data.sample_key
					console.log(xdata)
					ydata = data.sample_value
					console.log(ydata)
					var dataPoint = [];
					function addData(s,d) {
                	for (var i = 0; i < s.length; i++) {
                  	for(var j=0;j<d.length;j++){
                		dataPoint.push({
                			x: new Date(s[i]),
                			y: d[j]
                		});
                   }
                 }
                }
                addData(xdata,ydata);
					var chart = new CanvasJS.Chart("chartContainer",
                {
                    animationEnabled: true,
                    theme: "light2",
                    title: {
                        text: "Date Time Formatting"               
                    },
                    axisX:{      
                        valueFormatString: "D-MM hh:mm tt" ,
                        labelAngle: -50
                    },
                    axisY: {
                      valueFormatString: "#,###"
                  },
            
                  data: [
                  {        
                    type: "spline",
                    color: "rgba(0,75,141,0.7)",
                    dataPoints: dataPoint
                }
                
                ]
            });
            
            chart.render();
            
                    },

            error: function(error_data){
                console.log("error")
                console.log(error_data)
            }
})
pt1 = new Date("2019-03-18T23:32:11.114Z");
pt2 = new Date("2019-03-17T23:32:11.114Z");

    
{% endblock %}
</script>

{% block content %}
<div id="chartContainer" style="height: 300px; width: 100%;">
</div>
{% endblock content %}
